package com.example.ticketsservice.Controller;

import com.example.ticketsservice.Mapper.CommentMapper;
import com.example.ticketsservice.Mapper.JoinerMapper;
import com.example.ticketsservice.Mapper.TicketMapper;
import com.example.ticketsservice.Model.Comment;
import com.example.ticketsservice.Model.Ticket;
import com.example.ticketsservice.Service.Sorter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class TicketController {
    @Autowired
    Sorter sorter;
    TicketMapper ticketMapper;
    CommentMapper commentMapper;
    JoinerMapper joinerMapper;

    public TicketController (TicketMapper ticketMapper, CommentMapper commentMapper, JoinerMapper joinerMapper){
        this.ticketMapper = ticketMapper;
        this.commentMapper = commentMapper;
        this.joinerMapper = joinerMapper;
    }

    @RequestMapping("/tickets/getAll")
    public List<Ticket> getList(){
        List<Ticket> tickets = ticketMapper.returnAll();
        sorter.sortArray(tickets);
        return tickets;
    }

    @PostMapping("tickets/add")
    public String addTicket(@RequestBody Ticket ticket){
        ticket.setStatus("Ready");
        ticketMapper.addTicket(ticket);
        return "Ticket with ready status added";
    }
    @GetMapping("tickets/get/{status}")
    public List<Ticket> findTicket(@PathVariable String status){
        List<Ticket> tickets = ticketMapper.findTicket(status);
        sorter.sortArray(tickets);
        return tickets;
    }

    @PutMapping("tickets/changeStatus/{tid}/{status}")
    public String changeStatus (@PathVariable int tid, @PathVariable String status){
            Ticket ticket = ticketMapper.findById(tid);
            ticketMapper.changeStatus(tid, status);
            String comment = "\nTicket with id " +tid +" status has been changed from " +ticket.getStatus() +" to " +status;
            commentMapper.addComment(comment, tid);

            Comment newComment = commentMapper.selectLast();
            joinerMapper.createJoiner(newComment.getCId(),tid);
            return "Ticket with id " +tid +" status has been changed from " +ticket.getStatus() +" to " +status;

    }
    @GetMapping("tickets/getComments/{tid}")
    public Ticket getComments(@PathVariable int tid) {
        return ticketMapper.getComments(tid);
    }
    @GetMapping("tickets/getTickets/{tid}")
    public Ticket getTickets(@PathVariable int tid){
        Ticket ticket = ticketMapper.findById(tid);
        Comment lastComment = commentMapper.selectLastComment(ticket.getId());
        ticket.getComments().add(lastComment);
        return ticket;
    }

}
