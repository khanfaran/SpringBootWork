package com.example.assignmentservice.Controller;

import com.example.assignmentservice.Mapper.AssignmentMapper;
import com.example.assignmentservice.Model.Assignment;
import com.example.assignmentservice.Model.Ticket;
import com.example.assignmentservice.Model.User;
import com.example.assignmentservice.Service.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

@RestController
public class AssignmentController {
    @Autowired
    RestTemplate restTemplate;
    @Autowired
    Validator validator;

    AssignmentMapper assignmentMapper;
    public AssignmentController(AssignmentMapper assignmentMapper){
        this.assignmentMapper = assignmentMapper;
    }
    @GetMapping("assignment/getAllTickets")
    public void getTickets() throws MalformedURLException {
        URL url = new URL("http://localhost/8081/tickets/getAll");
        Ticket[] tickets = restTemplate.getForObject("http://localhost:8081/tickets/getAll",Ticket[].class);
        System.out.println(tickets.length);
        ;
    }
    @GetMapping("assignment/getStatusTickets/{status}")
    public void getStatusTickets(@PathVariable String status) throws MalformedURLException {
        URL url = new URL("http://localhost/8081/tickets/get/{status}");
        Ticket[] tickets = restTemplate.getForObject("http://localhost:8081/tickets/get/"+status,Ticket[].class);
        System.out.println(tickets.length);
        ;
    }
    @PostMapping("assignment/create")
    public String createAssignment(@RequestBody Assignment assignment){
        String message = "";
        User user = restTemplate.getForObject("http://localhost:8080/users/findUser/"+assignment.getUid(), User.class);
        System.out.println(user.getId());
        if (!validator.checkUserTickets(user)){
           message += "Maximum tickets reached. Ticket will be assigned to next user\n";
           user = restTemplate.getForObject("http://localhost:8080/users/getEligible", User.class);
           if (user == null){
               return "All users are assigned the maximum number of tickets";
           }
            else{
                assignment.setUid(user.getId());
           }
        }
        assignmentMapper.createAssignment(assignment);
        user = restTemplate.getForObject("http://localhost:8080/users/addTicket/"+assignment.getUid(), User.class);
        message+="Ticket Added";
        return message;
    }
    @GetMapping("assignment/getAll")
    public List<Assignment> getAssignments (){
        return assignmentMapper.getAll();
    }
}
