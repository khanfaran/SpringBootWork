package com.example.usermicro.Mapper;

public interface CommentMapper {
}
