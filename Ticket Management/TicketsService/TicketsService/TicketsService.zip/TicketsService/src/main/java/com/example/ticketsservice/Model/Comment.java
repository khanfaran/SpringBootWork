package com.example.ticketsservice.Model;

public class Comment {
    private int cid;
    private String comment;
    private int tid;
    public Comment() {
    }

    public int getCId() {
        return cid;
    }

    public void setId(int cid) {
        this.cid = cid;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getTid() {
        return tid;
    }

    public void setTid(int tid) {
        this.tid = tid;
    }

}
