package com.example.usermicro.Controller;

import com.example.usermicro.Mapper.UserMapper;
import com.example.usermicro.Model.User;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UserController {
    UserMapper userMapper;
    public UserController(UserMapper userMapper){
        this.userMapper = userMapper;
    }

    @RequestMapping("/users/getAll")
    public List<User> getList(){
        return userMapper.getUsers();
    }

    @GetMapping("users/addTicket/{id}")
    public User addTicket(@PathVariable int id){
        userMapper.addTicket(id);
        return userMapper.findUser(id);
    }
    @GetMapping("users/getEligible")
    public User getEligibleUser(){
        return userMapper.getEligibleUser();
    }
    @GetMapping ("users/findUser/{id}")
    public User findUser(@PathVariable int id){
        return userMapper.findUser(id);
    }
}
